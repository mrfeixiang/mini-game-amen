// ContentView.swift
// Amen (MacOS Game)
//
// Created by mizi fei on 11/4/24.
//

import SwiftUI

struct PriestGameView: View {
    @State private var scenarioIndex = 0
    @State private var showOutcome = false
    @State private var playerScore = 0
    @State private var outcomeMessage = ""

    // 添加了历史背景的情景
    let scenarios = [
        "二战后，罗马的街头满目疮痍，人们生活在饥饿和绝望中。作为教皇，你需要鼓励并帮助他们恢复信心。",
        "意大利北部的一个村庄被战后的疾病折磨。你能否带领人们战胜恐惧并找到希望？"
    ]

    let choices = [
        ["亲自探访灾民并给予安慰", "组织粮食和衣物的分发", "主持一场祈祷仪式"],
        ["提供医疗帮助并安抚人心", "鼓励社区互助", "倡导自我隔离防止疾病蔓延"]
    ]

    let outcomes = [
        ["你的亲自探访让人们感受到温暖和希望，他们心中重新燃起了信心。 (+10 分)",
         "粮食和衣物的分发让人们的生活得到了一定程度的改善。 (+7 分)",
         "祈祷仪式让人们在精神上得到安慰，但物质问题依然存在。 (+5 分)"],
        ["医疗帮助减少了疾病传播，村庄的健康状况开始好转。 (+10 分)",
         "社区互助增强了人们的凝聚力，生活恢复了一些生机。 (+7 分)",
         "虽然自我隔离遏制了疾病的扩散，但恐惧加深了孤立感。 (+3 分)"]
    ]

    var body: some View {
        VStack {
            if showOutcome {
                outcomeView()
            } else {
                gameView()
            }
        }
        .frame(width: 600, height: 450)
        .padding()
    }

    @ViewBuilder
    private func outcomeView() -> some View {
        Text(outcomeMessage)
            .font(.headline)
            .padding()
            .foregroundColor(.green)

        if scenarioIndex < scenarios.count - 1 {
            Button("继续") {
                nextScenario()
            }
            .gameButtonStyle()
        } else {
            VStack {
                Text("游戏结束！您的总得分：\(playerScore)")
                    .font(.title2)
                    .padding()

                Button("重新开始游戏") {
                    restartGame()
                }
                .gameButtonStyle()
            }
        }
    }

    @ViewBuilder
    private func gameView() -> some View {
        Text(scenarios[scenarioIndex])
            .font(.title)
            .padding()

        ForEach(0..<choices[scenarioIndex].count, id: \.self) { index in
            Button(action: {
                onChoiceSelected(index)
            }) {
                Text(choices[scenarioIndex][index])
            }
            .gameButtonStyle()
        }
    }

    private func onChoiceSelected(_ choiceIndex: Int) {
        guard scenarioIndex < outcomes.count, choiceIndex < outcomes[scenarioIndex].count else { return }
        outcomeMessage = outcomes[scenarioIndex][choiceIndex]
        playerScore += calculateScore(choiceIndex)
        showOutcome = true
    }

    private func calculateScore(_ choiceIndex: Int) -> Int {
        switch choiceIndex {
        case 0:
            return 10
        case 1:
            return 7
        case 2:
            return 5
        default:
            return 0
        }
    }

    private func nextScenario() {
        showOutcome = false
        if scenarioIndex < scenarios.count - 1 {
            scenarioIndex += 1
        } else {
            showOutcome = true
        }
    }

    private func restartGame() {
        scenarioIndex = 0
        playerScore = 0
        showOutcome = false
        outcomeMessage = ""
    }
}

struct ContentView: View {
    var body: some View {
        PriestGameView()
    }
}

@main
struct VisionProPriestGameApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

extension View {
    func gameButtonStyle() -> some View {
        self
            .padding()
            .background(Color.blue.opacity(0.7))
            .cornerRadius(10)
            .foregroundColor(.white)
            .padding(.bottom, 5)
    }
}
