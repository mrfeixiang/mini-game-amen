//
//  AmenTests.swift
//  AmenTests
//
//  Created by mizi fei on 11/4/24.
//

import Testing
@testable import Amen

struct AmenTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
